from flask import Flask, render_template, request, redirect, url_for
from flask_s3 import FlaskS3
import os
from werkzeug.utils import secure_filename
import boto3

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['S3_BUCKET'] = 'receipt-scan-sustainable-spend'
app.config['AWS_ACCESS_KEY_ID'] = 'AKIAVRUVT4AJM7S47CXQ'
app.config['AWS_SECRET_ACCESS_KEY'] = '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'
app.config['AWS_REGION'] = 'ap-south-1'

s3 = boto3.client('s3',
                  aws_access_key_id=app.config['AWS_ACCESS_KEY_ID'],
                  aws_secret_access_key=app.config['AWS_SECRET_ACCESS_KEY'],
                  region_name=app.config['AWS_REGION'])

def upload_to_s3(file_path, s3_key):
    s3.upload_file(file_path, app.config['S3_BUCKET'], s3_key)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']

    if file.filename == '':
        return redirect(request.url)

    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        s3_key = f'uploads/{filename}'
        upload_to_s3(file_path, s3_key)

        os.remove(file_path)

        return f'File successfully uploaded to S3 at key: {s3_key}'

if __name__ == '__main__':
    app.run(debug=True)
